package com.mark.companion

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("mark_companion", Context.MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var feed: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var pcUrlInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var voiceRequestCode = 241
    private var webView: android.webkit.WebView? = null
    private var pendingWebPermission: android.webkit.PermissionRequest? = null
    private var busy = false
    private val bg = Color.rgb(3, 8, 13)
    private val panel = Color.rgb(8, 20, 29)
    private val cyan = Color.rgb(0, 212, 255)
    private val white = Color.rgb(220, 235, 243)
    private val muted = Color.rgb(126, 153, 166)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        tts = TextToSpeech(this, this)
        if (prefs.getBoolean("setup_done", false)) showAgentScreen() else showConnectScreen()
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale.getDefault()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(10), dp(16), dp(12))
        }
    }

    private fun makeText(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
    }

    private fun makeButton(label: String, primary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false
        setTextColor(if (primary) bg else cyan)
        background = rounded(if (primary) cyan else panel, 13)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun addLogo(parent: LinearLayout, subtitle: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(18)) }
        val orb = TextView(this).apply {
            text = "M"; textSize = 25f; setTypeface(Typeface.DEFAULT, Typeface.BOLD); setTextColor(bg); gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cyan, Color.rgb(0, 110, 170))).apply { shape = GradientDrawable.OVAL }
        }
        row.addView(orb, LinearLayout.LayoutParams(dp(54), dp(54)))
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        labels.addView(makeText("MARK", 23f, white, true))
        labels.addView(makeText(subtitle, 11f, muted))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row)
    }

    private fun showConnectScreen() {
        webView?.stopLoading(); webView = null
        root = baseLayout()
        addLogo(root, "PERSONAL AI COMPANION")
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(24), dp(20), dp(24)); background = rounded(panel, 22)
        }
        hero.addView(makeText("CONNECT YOUR PC", 18f, white, true))
        hero.addView(makeText("Paste the dashboard address from MARK on your computer. This screen will disappear after saving.", 13f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(18)) })
        pcUrlInput = EditText(this).apply {
            hint = "https://192.168.1.x:8765"; setSingleLine(true); textSize = 13f
            setTextColor(white); setHintTextColor(muted); background = rounded(bg, 12); setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("pc_url", "") ?: "")
        }
        hero.addView(pcUrlInput, LinearLayout.LayoutParams(-1, dp(50)))
        hero.addView(makeButton("SAVE & OPEN MARK", true) { savePcUrl() }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
        hero.addView(makeButton("SKIP — PHONE ONLY") { prefs.edit().putBoolean("setup_done", true).apply(); showAgentScreen() }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(7) })
        hero.addView(makeText("You can change or disconnect this link later in Settings. No Bluetooth and no notification-reading permission.", 11f, muted).apply { setPadding(0, dp(16), 0, 0) })
        root.addView(hero)
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(makeText("MARK • PRIVATE BY DESIGN", 10f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) })
        setContentView(root)
    }

    private fun savePcUrl() {
        var url = pcUrlInput.text.toString().trim()
        if (url.isBlank()) { pcUrlInput.error = "Enter the PC dashboard URL"; return }
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
        val uri = try { Uri.parse(url) } catch (_: Exception) { null }
        if (uri?.host.isNullOrBlank()) { pcUrlInput.error = "Enter a valid URL"; return }
        // Keep only the stable server origin; QR auto-login links contain one-time keys that expire.
        val stableUrl = Uri.Builder().scheme(uri!!.scheme ?: "https").encodedAuthority(uri.encodedAuthority).path("/").build().toString().trimEnd('/')
        prefs.edit().putString("pc_url", stableUrl).putBoolean("setup_done", true).apply()
        showAgentScreen()
    }

    private fun showAgentScreen() {
        root = baseLayout()
        addLogo(root, "YOUR PHONE AGENT")
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        status = makeText("● PHONE READY", 11f, cyan, true)
        top.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(makeButton("PC CONTROL") { openPcDashboard() })
        top.addView(makeButton("⚙") { showSettingsDialog() }, LinearLayout.LayoutParams(dp(52), dp(46)).apply { leftMargin = dp(5) })
        root.addView(top)
        val divider = View(this).apply { setBackgroundColor(Color.rgb(22, 54, 68)) }
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(10); bottomMargin = dp(8) })
        chatScroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        feed = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(14)) }
        chatScroll.addView(feed)
        root.addView(chatScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (feed.childCount == 0) addBubble("MARK", "I'm ready. Try: ‘Open YouTube’, ‘Search the web for…’, ‘Set a timer for 5 minutes’, or ‘Open Wi-Fi settings’. Add your Gemini API key in Settings to enable AI-powered requests.", false)
        val compose = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        input = EditText(this).apply {
            hint = "Tell MARK what to do on this phone…"; textSize = 13f; setTextColor(white); setHintTextColor(muted)
            background = rounded(panel, 15); setPadding(dp(12), dp(4), dp(12), dp(4)); minHeight = dp(48)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ -> if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) { sendCommand(); true } else false }
        }
        compose.addView(input, LinearLayout.LayoutParams(0, dp(50), 1f))
        compose.addView(makeButton("🎙") { startVoiceInput() }, LinearLayout.LayoutParams(dp(54), dp(50)).apply { leftMargin = dp(5) })
        compose.addView(makeButton("SEND", true) { sendCommand() }, LinearLayout.LayoutParams(dp(70), dp(50)).apply { leftMargin = dp(5) })
        root.addView(compose)
        root.addView(makeText("PHONE ACTIONS RUN ON THIS PHONE • PC CONTROL IS SEPARATE", 9f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) })
        setContentView(root)
    }

    private fun openPcDashboard() {
        val url = prefs.getString("pc_url", "") ?: ""
        if (url.isBlank()) { showConnectScreen(); return }
        val frame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        bar.addView(makeText("MARK · PC CONTROL", 12f, cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(makeButton("PHONE AGENT") { webView?.stopLoading(); webView = null; showAgentScreen() })
        frame.addView(bar)
        val browser = android.webkit.WebView(this).apply {
            setBackgroundColor(bg)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webChromeClient = object : android.webkit.WebChromeClient() {
                override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                    val wantsAudio = request.resources.contains(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (!wantsAudio) { request.deny(); return }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        runOnUiThread { request.grant(arrayOf(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)) }
                    } else {
                        pendingWebPermission = request
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 242)
                    }
                }
            }
            webViewClient = object : android.webkit.WebViewClient() {
                override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                    status.text = "● PC PAGE LOADED"
                }
                override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                    if (request?.isForMainFrame == true) {
                        status.text = "● PC DISCONNECTED"
                        prefs.edit().putBoolean("setup_done", false).apply()
                        Toast.makeText(this@MainActivity, "PC link lost. Enter the stable PC dashboard URL again when ready.", Toast.LENGTH_LONG).show()
                        window.decorView.postDelayed({ if (webView === view) showConnectScreen() }, 900)
                    }
                }
                override fun onReceivedSslError(view: WebView?, handler: android.webkit.SslErrorHandler?, error: android.net.http.SslError?) {
                    AlertDialog.Builder(this@MainActivity).setTitle("MARK PC certificate")
                        .setMessage("Only trust this certificate if this is your own PC on a trusted network.")
                        .setNegativeButton("Cancel") { _, _ -> handler?.cancel() }
                        .setPositiveButton("Trust for this visit") { _, _ -> handler?.proceed() }.show()
                }
            }
        }
        webView = browser
        frame.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(frame)
        browser.loadUrl(url)
    }

    private fun showSettingsDialog() {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        wrap.addView(makeText("GEMINI API KEY", 11f, cyan, true))
        keyInput = EditText(this).apply {
            hint = "Paste your API key"; setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("gemini_key", "") ?: ""); textSize = 13f
        }
        wrap.addView(keyInput)
        wrap.addView(makeText("Stored in this app's private preferences. Never share screenshots or export the key.", 10f, muted))
        val pcInput = EditText(this).apply { hint = "PC dashboard URL (optional)"; setSingleLine(true); setText(prefs.getString("pc_url", "") ?: "") }
        wrap.addView(pcInput)
        val dialog = AlertDialog.Builder(this).setTitle("MARK SETTINGS").setView(wrap)
            .setPositiveButton("SAVE", null).setNeutralButton("DISCONNECT PC", null).setNegativeButton("CANCEL", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val key = keyInput.text.toString().trim()
                val pc = pcInput.text.toString().trim()
                prefs.edit().putString("gemini_key", key).putString("pc_url", pc).putBoolean("setup_done", true).apply()
                dialog.dismiss()
                status.text = if (key.isBlank()) "● PHONE READY · API KEY NEEDED" else "● PHONE AGENT READY"
                toast("Settings saved on this phone")
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                prefs.edit().remove("pc_url").putBoolean("setup_done", false).apply(); dialog.dismiss(); showConnectScreen()
            }
        }
        dialog.show()
    }

    private fun addBubble(who: String, text: String, user: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(if (user) Color.rgb(8, 45, 59) else panel, 16)
        }
        card.addView(makeText(who, 10f, if (user) cyan else muted, true))
        card.addView(makeText(text, 14f, white).apply { setPadding(0, dp(4), 0, 0) })
        val lp = LinearLayout.LayoutParams(if (user) (resources.displayMetrics.widthPixels * .82f).toInt() else -1, -2)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.topMargin = dp(5); lp.bottomMargin = dp(5)
        feed.addView(card, lp)
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendCommand() {
        if (busy) return
        val command = input.text.toString().trim()
        if (command.isBlank()) return
        input.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        addBubble("YOU", command, true)
        busy = true; status.text = "● THINKING…"
        val key = prefs.getString("gemini_key", "") ?: ""
        worker.execute {
            val result = if (key.isBlank()) basicPhoneAction(command) else askGemini(key, command)
            runOnUiThread {
                busy = false
                status.text = "● PHONE READY"
                addBubble("MARK", result.reply, false)
                if (result.speak) speak(result.reply)
                if (result.action.isNotBlank()) performAction(result.action, result.target)
            }
        }
    }

    private data class AgentResult(val reply: String, val action: String = "", val target: String = "", val speak: Boolean = true)

    private fun askGemini(apiKey: String, command: String): AgentResult {
        return try {
            val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + Uri.encode(apiKey))
            val conn = (endpoint.openConnection() as HttpURLConnection).apply { requestMethod = "POST"; connectTimeout = 12000; readTimeout = 25000; doOutput = true; setRequestProperty("Content-Type", "application/json") }
            val system = "You are MARK, a concise, witty phone assistant. Respond ONLY as JSON with keys reply, action, target. Allowed action values: none, open_app, open_url, web_search, open_settings, set_timer, set_alarm. The app will execute only these whitelisted actions on the user's Android phone. Do not claim an action is complete before it happens. Never request passwords, bypass lock screens, read notifications, send messages, make purchases, or change security settings. For app opening, target is the app name. For URLs/search, target is the destination or search query. For timer, target is minutes as a number. For alarm, target is HH:mm 24-hour time. If the request needs unsupported capability, action=none and explain limitation. User request: ${command.replace("\"", "'")} ";
            val payload = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", command)))))
                .put("generationConfig", JSONObject().put("temperature", 0.25).put("responseMimeType", "application/json"))
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val raw = stream.bufferedReader().use { it.readText() }
            if (conn.responseCode !in 200..299) throw Exception("Gemini API returned ${conn.responseCode}. Check your API key and internet connection.")
            val text = JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val obj = JSONObject(text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
            val reply = obj.optString("reply", "I'm ready.")
            val action = obj.optString("action", "none")
            val target = obj.optString("target", "")
            if (action !in setOf("none", "open_app", "open_url", "web_search", "open_settings", "set_timer", "set_alarm")) AgentResult(reply) else AgentResult(reply, if (action == "none") "" else action, target)
        } catch (e: Exception) {
            AgentResult("I couldn't reach Gemini: ${e.message ?: "check the network and API key"}. I can still handle basic phone commands without an API key.")
        }
    }

    private fun basicPhoneAction(command: String): AgentResult {
        val c = command.lowercase(Locale.ROOT)
        val appNames = listOf("youtube", "chrome", "camera", "settings", "whatsapp", "maps", "gmail", "clock", "calculator", "phone", "messages", "play store", "files")
        val app = appNames.firstOrNull { c.contains("open $it") || c.contains("launch $it") || c == it }
        if (app != null) return AgentResult("Okay, opening $app.", "open_app", app)
        if (c.contains("wifi") || c.contains("wi-fi")) return AgentResult("Opening Wi-Fi settings.", "open_settings", "wifi")
        if (c.contains("bluetooth")) return AgentResult("Opening Bluetooth settings.", "open_settings", "bluetooth")
        if (c.contains("settings")) return AgentResult("Opening Android settings.", "open_settings", "settings")
        val timer = Regex("(?:timer|countdown).*?(\\d+)\\s*(seconds?|secs?|minutes?|mins?)|(?:set).*?(\\d+)\\s*(seconds?|secs?|minutes?|mins?)").find(c)
        if (timer != null) {
            val num = (timer.groups[1]?.value ?: timer.groups[3]?.value)?.toIntOrNull() ?: 5
            val unit = (timer.groups[2]?.value ?: timer.groups[4]?.value ?: "minutes")
            val minutes = if (unit.startsWith("sec")) maxOf(1, (num + 59) / 60) else num
            return AgentResult("Starting a $num $unit timer.", "set_timer", minutes.toString())
        }
        if (c.startsWith("search ")) return AgentResult("Opening a web search.", "web_search", command.substringAfter("search "))
        return AgentResult("I can open common apps, open Android settings, start timers, and search the web without an API key. Add your Gemini API key in Settings for natural-language planning.")
    }

    private fun performAction(action: String, target: String) {
        try {
            when (action) {
                "open_app" -> {
                    val name = target.trim().lowercase(Locale.ROOT)
                    val common = mapOf("youtube" to "com.google.android.youtube", "chrome" to "com.android.chrome", "whatsapp" to "com.whatsapp", "maps" to "com.google.android.apps.maps", "gmail" to "com.google.android.gm", "camera" to "com.android.camera", "play store" to "com.android.vending", "clock" to "com.google.android.deskclock", "calculator" to "com.google.android.calculator", "phone" to "com.google.android.dialer", "messages" to "com.google.android.apps.messaging")
                    val direct = common[name]?.let { packageManager.getLaunchIntentForPackage(it) }
                    val intent = direct ?: findLaunchIntentByLabel(name)
                    if (intent != null) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(intent); toast("Opened ${target}") }
                    else { addBubble("MARK", "I couldn't find an installed app named '$target'.", false) }
                }
                "open_url" -> {
                    var url = target.trim(); if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
                "web_search" -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(target))))
                "open_settings" -> {
                    val actionName = when (target.lowercase(Locale.ROOT)) { "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS; "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS; else -> Settings.ACTION_SETTINGS }
                    startActivity(Intent(actionName))
                }
                "set_timer" -> {
                    val mins = target.toIntOrNull()?.coerceIn(1, 1440) ?: 5
                    startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, mins * 60).putExtra(AlarmClock.EXTRA_MESSAGE, "MARK timer").putExtra(AlarmClock.EXTRA_SKIP_UI, false))
                }
                "set_alarm" -> {
                    val parts = target.split(":"); val hour = parts.getOrNull(0)?.toIntOrNull() ?: 7; val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
                    startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0,23)).putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0,59)).putExtra(AlarmClock.EXTRA_MESSAGE, "MARK alarm"))
                }
            }
        } catch (_: ActivityNotFoundException) { addBubble("MARK", "Android doesn't have an app available for that action.", false) }
        catch (e: Exception) { addBubble("MARK", "That action couldn't be completed: ${e.message ?: "unsupported on this phone"}.", false) }
    }

    private fun findLaunchIntentByLabel(query: String): Intent? {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = packageManager.queryIntentActivities(launcher, 0)
        val found = matches.firstOrNull { it.loadLabel(packageManager).toString().contains(query, true) }
        return found?.activityInfo?.let { Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(it.packageName, it.name) }
    }

    private fun startVoiceInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MARK")
            }
            startActivityForResult(intent, voiceRequestCode)
        } catch (_: Exception) { toast("Speech recognition is unavailable. Try typing instead.") }
    }

    @Deprecated("Legacy activity result keeps compatibility with Android 8+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequestCode && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input.setText(spoken); sendCommand() }
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts.speak(text.take(1800), TextToSpeech.QUEUE_FLUSH, null, "mark-reply")
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 242) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                request.grant(arrayOf(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            } else request?.deny()
        }
    }

    override fun onBackPressed() {
        if (webView != null) { webView?.stopLoading(); webView = null; showAgentScreen() }
        else super.onBackPressed()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
