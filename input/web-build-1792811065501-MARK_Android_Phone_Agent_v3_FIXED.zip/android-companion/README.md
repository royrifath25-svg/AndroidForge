# MARK Android Companion

A native Android companion with a dark/cyan MARK identity, phone-side chat, Android speech recognition and spoken replies, an optional PC dashboard link, and an optional Gemini API key entered by the user inside the app.

## Build
1. Open this `android-companion` folder in Android Studio, or upload this folder's source ZIP to AndroidForge.
2. Build a debug APK.
3. Install on Android 8.0/API 26 or newer.
4. On first launch, enter the stable MARK PC dashboard base URL if you want PC control. Use the PC's base address such as `https://192.168.1.20:8765`, not the temporary QR/auto-login URL. The app strips path/query details so an expiring QR token is not saved as the server address.
5. In MARK Settings, paste your own Gemini API key to enable AI-powered phone command planning. The key is stored in this app's private preferences and is not included in the source ZIP.

## Phone-side actions
- Launch installed apps by name
- Open Android settings pages (including Wi-Fi/Bluetooth settings)
- Open websites and search the web
- Set a timer or alarm using Android's system intents
- Type or dictate a command; MARK speaks the response with Android Text-to-Speech

These are deliberately whitelisted actions, not unrestricted device control. Android will show system UI or ask for confirmation where required. The app does not read Android notifications, bypass the lock screen, send messages, make purchases, or silently change security settings.

## PC control and privacy
- `PHONE AGENT` handles supported phone actions locally.
- `PC CONTROL` opens the desktop MARK dashboard; commands entered there are PC commands.
- Disconnect/edit the saved PC URL through Settings; if the PC link fails, the app returns to the URL screen.
- Use trusted Wi-Fi or a private VPN. Do not expose the PC dashboard port directly to the public internet.
- No Bluetooth permission is requested. The API key is entered by the user and is not bundled.

## Current limitations
- This is not an always-on background wake-word service. Voice input is initiated by tapping the microphone and uses Android speech recognition.
- Phone actions are limited to the supported whitelist. More device actions can be added explicitly and tested per Android version.
- PC control depends on the desktop MARK server being reachable and paired/authenticated.
