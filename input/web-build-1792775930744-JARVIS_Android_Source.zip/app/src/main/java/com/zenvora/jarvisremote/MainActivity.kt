package com.zenvora.jarvisremote

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONObject

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var address: EditText
    private lateinit var token: EditText
    private lateinit var command: EditText
    private lateinit var status: TextView
    private val cyan = Color.rgb(0, 217, 255)
    private val pale = Color.rgb(143, 252, 255)
    private val bg = Color.rgb(1, 7, 13)
    private val panel = Color.rgb(2, 19, 29)
    private val voiceRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 29f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            letterSpacing = .18f
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "MOBILE COMMAND INTERFACE"
            textSize = 11f
            setTextColor(pale)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(20))
        }
        root.addView(subtitle, matchWrap())

        address = field("Laptop address, e.g. http://192.168.1.10:8765")
        address.setText("http://")
        token = field("Pairing token shown in desktop JARVIS")
        token.inputType = 129
        root.addView(card("CONNECTION"))
        root.addView(address, matchWrap())
        root.addView(token, matchWrap())
        addButton(root, "CONNECT / CHECK STATUS") { connect() }
        status = TextView(this).apply {
            text = "Not connected. Start PHONE LINK in desktop JARVIS first."
            setTextColor(pale)
            textSize = 13f
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }
        root.addView(status, matchWrap())

        root.addView(card("VOICE COMMANDS"))
        command = field("Try: open notepad, mirror phone, phone screenshot")
        root.addView(command, matchWrap())
        addButton(root, "🎙 SPEAK TO JARVIS") { startVoice() }
        addButton(root, "SEND COMMAND") { sendCommand(command.text.toString()) }

        root.addView(card("QUICK CONTROLS"))
        val examples = listOf(
            "Open Notepad" to "open notepad",
            "Open Calculator" to "open calculator",
            "Mirror phone on laptop" to "mirror phone",
            "Stop phone mirroring" to "stop mirroring",
            "Phone screenshot" to "phone screenshot",
            "Phone Home" to "phone home",
            "Phone Back" to "phone back",
            "Phone recent apps" to "phone recent apps",
            "Phone volume up" to "phone volume up",
            "Phone volume down" to "phone volume down",
            "Open YouTube on phone" to "open app youtube",
            "Open WhatsApp on phone" to "open app whatsapp",
            "Laptop status" to "laptop status",
            "Lock laptop" to "lock laptop"
        )
        examples.forEach { (label, cmd) -> addButton(root, label) { sendCommand(cmd) } }
        val note = TextView(this).apply {
            text = "Works on the same trusted Wi-Fi as your laptop. Phone mirroring uses the existing ADB/scrcpy setup on the laptop. Keep your pairing token private."
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(note, matchWrap())
    }

    private fun card(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(cyan)
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(18), dp(10), dp(8))
    }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.GRAY)
        setTextColor(pale)
        textSize = 14f
        setSingleLine(true)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.bottomMargin = dp(8)
        layoutParams = lp
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setTextColor(pale)
            setBackgroundColor(panel)
            isAllCaps = false
            textSize = 14f
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
        lp.topMargin = dp(5)
        lp.bottomMargin = dp(5)
        parent.addView(b, lp)
    }

    private fun connect() {
        request("GET", "/status", null) { result ->
            status.text = if (result.optBoolean("ok")) "CONNECTED — JARVIS is online" else result.optString("error", "Connection failed")
        }
    }

    private fun sendCommand(raw: String) {
        val normalized = normalizeCommand(raw)
        if (normalized.isBlank()) {
            Toast.makeText(this, "Enter or speak a command first", Toast.LENGTH_SHORT).show()
            return
        }
        status.text = "Sending: $normalized"
        val body = JSONObject().put("command", normalized)
        request("POST", "/command", body) { result ->
            status.text = if (result.optBoolean("ok")) "JARVIS accepted: $normalized" else result.optString("error", "Command failed")
        }
    }

    private fun normalizeCommand(raw: String): String {
        val text = raw.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")
        val direct = mapOf(
            "mirror my phone" to "mirror phone", "show my phone" to "mirror phone",
            "start screen mirroring" to "mirror phone", "stop screen mirroring" to "stop mirroring", "screenshot" to "phone screenshot",
            "take a screenshot" to "phone screenshot", "go home" to "phone home",
            "press back" to "phone back", "recent apps" to "phone recent apps",
            "volume up" to "phone volume up", "volume down" to "phone volume down",
            "open chrome" to "open app chrome", "open youtube" to "open app youtube",
            "open whatsapp" to "open app whatsapp", "open instagram" to "open app instagram",
            "open calculator on my laptop" to "open calculator", "open notepad on my laptop" to "open notepad",
            "open file explorer" to "open explorer", "lock my laptop" to "lock laptop",
            "what is my laptop status" to "laptop status"
        )
        return direct[text] ?: text
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 4103)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a command for JARVIS")
        }
        try { startActivityForResult(intent, voiceRequest) }
        catch (_: Exception) { Toast.makeText(this, "Speech recognition is unavailable on this phone", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Android speech result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (words.isNotBlank()) {
                command.setText(words)
                sendCommand(words)
            }
        }
    }

    private fun request(method: String, path: String, body: JSONObject?, done: (JSONObject) -> Unit) {
        val base = address.text.toString().trim().trimEnd('/')
        val secret = token.text.toString().trim()
        if (!base.startsWith("http://") && !base.startsWith("https://")) {
            status.text = "Enter the full laptop address from desktop JARVIS"
            return
        }
        if (secret.isBlank()) { status.text = "Enter the pairing token from desktop JARVIS"; return }
        status.text = "Connecting…"
        io.execute {
            val result = try {
                val connection = (URL(base + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 4500
                    readTimeout = 4500
                    setRequestProperty("X-Jarvis-Token", secret)
                    setRequestProperty("Accept", "application/json")
                    if (body != null) {
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
                    }
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                connection.disconnect()
                try { JSONObject(response) } catch (_: Exception) { JSONObject().put("ok", false).put("error", "HTTP $code") }
            } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "Could not reach laptop")
            }
            runOnUiThread { done(result) }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }
}
