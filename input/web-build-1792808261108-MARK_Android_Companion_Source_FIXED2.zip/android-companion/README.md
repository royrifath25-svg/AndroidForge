# MARK Companion Android source

This is a native Android wrapper for MARK's responsive phone dashboard. It is designed for Android 8.0 (API 26) and newer, including Android 11. It uses Wi-Fi or an internet/VPN connection; it does not use Bluetooth and it does not request access to read notifications.

## Open/build
1. Install Android Studio with Android SDK 35 and a compatible JDK (Android Studio's bundled JDK is fine).
2. Open this `android-companion` folder as a project and let Gradle sync/download the Android Gradle Plugin and Kotlin plugin.
3. Build with **Build → Build APK(s)**. The source has not been compiled in this environment because Android SDK/Gradle are not installed here.
4. Install the resulting debug APK on the phone.
5. Start MARK on the PC. In its Remote Control UI, pair the phone or note the dashboard URL. Enter the PC URL in this app, e.g. `https://192.168.1.20:8000`.
6. For the first self-signed certificate prompt, continue only if the address is your own PC on a trusted network.

## Important limits
- The app hosts the existing responsive dashboard; it is not yet a standalone offline AI.
- It requests microphone permission only when the dashboard asks for it. It does not read Android notifications.
- Always-on wake word while locked/background, foreground microphone service, and remote phone unlocking are not implemented. Android's secure lock screen is not bypassed.
- For access away from home, use a private VPN/mesh VPN. Do not port-forward MARK's dashboard ports to the public internet.
