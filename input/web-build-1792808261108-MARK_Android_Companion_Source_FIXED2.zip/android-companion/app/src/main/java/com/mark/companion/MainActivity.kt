package com.mark.companion

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.http.SslError
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("mark_companion", Context.MODE_PRIVATE) }
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var webView: WebView
    private var pendingWebPermission: PermissionRequest? = null
    private val micRequestCode = 241

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 8, 13)
        window.navigationBarColor = Color.rgb(3, 8, 13)
        buildLayout()
        val savedUrl = prefs.getString("pc_url", "") ?: ""
        if (savedUrl.isNotBlank()) webView.loadUrl(savedUrl)
    }

    private fun buildLayout() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(3, 8, 13))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val title = TextView(this).apply {
            text = "◉  MARK COMPANION"
            setTextColor(Color.rgb(0, 212, 255))
            textSize = 16f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(8))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(38)))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        urlInput = EditText(this).apply {
            hint = "https://PC-IP:8000"
            setSingleLine(true)
            textSize = 12f
            setTextColor(Color.rgb(220, 235, 243))
            setHintTextColor(Color.rgb(100, 129, 141))
            setBackgroundColor(Color.rgb(8, 20, 29))
            setPadding(dp(10), dp(2), dp(10), dp(2))
            setText(prefs.getString("pc_url", "") ?: "")
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        row.addView(urlInput, LinearLayout.LayoutParams(0, dp(44), 1f))
        val connect = Button(this).apply {
            text = "CONNECT"
            setTextColor(Color.rgb(0, 20, 28))
            setBackgroundColor(Color.rgb(0, 212, 255))
            setOnClickListener { connectToPc() }
        }
        row.addView(connect, LinearLayout.LayoutParams(dp(104), dp(44)).apply { leftMargin = dp(7) })
        root.addView(row)

        status = TextView(this).apply {
            text = "Set the MARK PC address. No Bluetooth is used."
            setTextColor(Color.rgb(100, 129, 141))
            textSize = 11f
            setPadding(dp(2), dp(5), dp(2), dp(7))
        }
        root.addView(status)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(3, 8, 13))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (!wantsAudio) { request.deny(); return }
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        runOnUiThread { request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) }
                    } else {
                        pendingWebPermission = request
                        ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), micRequestCode)
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    status.text = "Connecting to MARK PC…"
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    status.text = "Connected page loaded. Use Profile for voice/privacy settings."
                }
                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    if (request?.isForMainFrame == true) status.text = "Could not reach the PC. Check the URL and network, then retry."
                }
                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                    val host = try { Uri.parse(error?.url ?: "").host ?: "unknown host" } catch (_: Exception) { "unknown host" }
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("MARK local certificate")
                        .setMessage("The PC is presenting a certificate Android does not trust for $host. Only continue if this is your own MARK PC on a trusted network. Do not accept certificates on public Wi-Fi.")
                        .setNegativeButton("Cancel") { _, _ -> handler?.cancel() }
                        .setPositiveButton("Trust for this visit") { _, _ -> handler?.proceed() }
                        .setOnCancelListener { handler?.cancel() }
                        .show()
                }
            }
        }
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun connectToPc() {
        var url = urlInput.text.toString().trim()
        if (url.isBlank()) { urlInput.error = "Enter the PC dashboard URL"; return }
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
        val uri = try { Uri.parse(url) } catch (_: Exception) { null }
        if (uri?.host.isNullOrBlank()) { urlInput.error = "Enter a valid PC URL"; return }
        urlInput.setText(url)
        prefs.edit().putString("pc_url", url.trimEnd('/')).apply()
        status.text = "Connecting over Wi-Fi/network…"
        webView.loadUrl(url.trimEnd('/'))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micRequestCode) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            } else {
                request?.deny()
                Toast.makeText(this, "Microphone permission was not granted", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
